# The Assisted Climb

A school-ready AI-assisted learning platform where teachers create classes with join codes, students work through structured learning stages (MAP, TORCH, COMPASS, EMBED), and a Socratic AI tutor (powered by the teacher's own Gemini or Azure OpenAI key) guides discovery in the TORCH stage.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19 + Vite + Tailwind CSS + wouter + shadcn/ui
- API: Express 5 + express-session
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Auth: express-session (cookie-based, shared for both teachers and students)
- Password hashing: bcryptjs
- AI: @google/generative-ai (Gemini), openai (Azure OpenAI)

## Where things live

- **DB schema** — `lib/db/src/schema/` (teachers, classes, studentSessions, stageEntries, chatMessages)
- **API contract** — `lib/api-spec/openapi.yaml` (source of truth)
- **Generated Zod schemas** — `lib/api-zod/src/generated/api.ts`
- **Generated React Query hooks** — `lib/api-client-react/src/generated/api.ts`
- **API routes** — `artifacts/api-server/src/routes/` (auth.ts, teacher/, student/)
- **Middleware** — `artifacts/api-server/src/middlewares/` (teacherAuth, studentAuth)
- **Crypto util** — `artifacts/api-server/src/lib/crypto.ts` (AES-256-GCM encrypt/decrypt)
- **AI proxy util** — `artifacts/api-server/src/lib/ai.ts` (callGemini, callAzureOpenAI)
- **Frontend** — `artifacts/assisted-climb/`

## Architecture decisions

- Teacher and student sessions both use express-session with a single shared session store, namespaced via `req.session.teacherId` vs `req.session.studentSessionId`. This avoids two separate auth systems while keeping roles clearly separated at the middleware level.
- API keys are encrypted at rest using AES-256-GCM. The encryption key is derived from `SESSION_SECRET` using scrypt. The IV and auth tag are stored alongside the ciphertext (`iv:authTag:ciphertext` hex). The plaintext key is never returned to clients — only a masked version (first 4 + last 4 chars).
- Teacher auth middleware (`requireTeacher`) is applied per-route (not via `router.use()`) to avoid intercepting requests to other routers that share the same Express Router chain.
- Student sessions are created on join without requiring an account — only a name and class code. The session is stored in the DB; the cookie tracks session ID.
- Stage entries are upserted (update if exists, insert if not) so students can revisit and refine their work.

## Product

- Teachers register with email/password, create classes (6-char join code), and save their Gemini or Azure OpenAI API key
- Students join with their name + class code (no account needed) and progress through MAP → TORCH → COMPASS → EMBED
- TORCH stage: students chat with an AI tutor — the server proxies to Gemini/Azure using the teacher's encrypted key
- Teachers see all students in their class, their latest stage, full stage content, and full chat history

## User preferences

- No per-teacher API key management — IT configures centrally
- No student accounts — name + code only
- School data stays with the school (per-instance deployment)
- AI should guide thinking, never complete tasks for students

## Gotchas

- Always run codegen after editing `lib/api-spec/openapi.yaml`: `pnpm --filter @workspace/api-spec run codegen`
- Orval only generates `<OperationId>Response` Zod schemas for 200 responses (not 201). For POST 201 responses, reuse the closest matching response schema (e.g. `LoginTeacherResponse` for the register 201).
- `bcrypt` (native) is blocked by the workspace security policy. Use `bcryptjs` (pure JS) instead.
- Session cookies use `sameSite: "none"` in production (required for cross-origin iframe previews) and `sameSite: "lax"` in development
- The DB lib must be built (`pnpm run typecheck:libs`) before the API server typecheck will pass
- Run `pnpm --filter @workspace/db run push` after any schema changes
- The `stageEnum` and `messageRoleEnum` Postgres enums must exist before tables that reference them — always push schema in order

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
